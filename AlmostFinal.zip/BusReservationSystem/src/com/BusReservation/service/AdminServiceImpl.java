package com.BusReservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BusReservation.dao.IAdminDao;
import com.BusReservation.model.Admin;
import com.BusReservation.model.BusDetails;

@Service
public class AdminServiceImpl implements IAdminService{

	@Autowired
	IAdminDao adminDao;
	
	 public boolean verifyAdmin(Admin a)
	 {
		return adminDao.verifyAdmin(a);
	 }

	@Override
	public void addBus(BusDetails busDetails) {
		
		 adminDao.addBus(busDetails);
		
	}

	@Override
	public List<BusDetails> ViewAllBus() {
		
		return adminDao.ViewAllBus();
	}

	@Override
	public List<BusDetails> ViewAllUser() {
		
		return adminDao.ViewAllUser();
	}


	
}
