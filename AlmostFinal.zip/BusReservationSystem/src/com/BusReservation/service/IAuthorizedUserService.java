package com.BusReservation.service;

import java.util.ArrayList;
import java.util.List;
import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.model.PassengerDetails;

public interface IAuthorizedUserService {
	List fetchPassword(String email);
	
	void AddUser(AuthorizedUser authuser);
	
	boolean verifyUser(String username,String passwrod);
	
	public List<AuthorizedUser> getUserDetails(String username);
	
	public List<BusDetails> getBusDetails(String busname);
	
	public List<PassengerDetails> registerPassenger(PassengerDetails pdetail) ;
	
	public boolean seatCalculate(String seattotal, int busId);
	
	public ArrayList<String> getBookedSeats(String busname) ;
	
	public List<PassengerDetails> fetchPassengerDetails(String username);
}
