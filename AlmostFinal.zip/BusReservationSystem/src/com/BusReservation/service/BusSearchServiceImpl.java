package com.BusReservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BusReservation.dao.IBusSearchDao;
import com.BusReservation.model.BusDetails;

@Service
public class BusSearchServiceImpl implements IBusSearchService {

	@Autowired
	IBusSearchDao bussearchdao;
	
	@Override
	public List<BusDetails> fetchBus(String sectorfrom, String sectorto, String journeyDate, String returnDate) {
	
		return bussearchdao.fetchBus(sectorfrom, sectorto,  journeyDate, returnDate);
		
	}

}
