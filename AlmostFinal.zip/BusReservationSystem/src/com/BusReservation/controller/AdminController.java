package com.BusReservation.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.BusReservation.model.Admin;
import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.service.IAdminService;

@Controller
public class AdminController {

	@Autowired
	IAdminService adminService;

	@RequestMapping("/adminLogin")
	public String showLoginView(Model modal)
	{
		System.out.println("inside admin");
		modal.addAttribute("admin", new Admin());
		String view="adminLogin";
		return view;
	}
	
	@RequestMapping(value="/adminLoginCall",method=RequestMethod.POST)
	public String adminLoginValidation(@Valid @ModelAttribute("admin") 
	Admin admin ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
	
		if(adminService.verifyAdmin(admin))
		{
			return "AdminDashBoard";
		}
		
		return "adminLogin";
	}

	@RequestMapping("/addBus")
	public String addBus(Model modal)
	{
		modal.addAttribute("busDetails", new BusDetails());
		String view="AddBus";
		return view;
	}
	
	
	@RequestMapping(value="/addBusProcess",method=RequestMethod.POST)
	public String addBusProcessing(@Valid @ModelAttribute("busDetails") 
	BusDetails busDetails ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		System.out.println("inside..add bus controller");
		adminService.addBus(busDetails);
		
		return "success";
		
	}
	
	
	
	@RequestMapping("/viewBus")
	public String viewAllBus(Model model,HttpServletRequest req)
	{
		System.out.println("inside admin view all");
	   List<BusDetails> bDetails=adminService.ViewAllBus();
		
	   model.addAttribute("busDetails", bDetails);
		return "AllBusDetails";
	}
	
	
	
	@RequestMapping("/viewUser")
	public String viewAllUser(Model model,HttpServletRequest req)
	{
		System.out.println("inside admin view all");
	   List<BusDetails> user=adminService.ViewAllUser();
		
	   model.addAttribute("allUser", user);
		return "AllUserDetails";
	}
	
}
