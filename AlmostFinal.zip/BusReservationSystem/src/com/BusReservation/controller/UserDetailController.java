package com.BusReservation.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.BusReservation.dao.IAuthorizedUserDao;
import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.PassengerDetails;

@Controller
public class UserDetailController {

	@Autowired
	IAuthorizedUserDao authuserservice;
	
	
	@RequestMapping("/myBooking")
	public String fetchMyBooking(Model model,HttpServletRequest req,HttpSession s)
	{
	
		
		
			String username=(String)s.getAttribute("username");
					System.out.println("qwerqrqwrqwrqw"+username);
		List<PassengerDetails> pDetails=authuserservice.fetchPassengerDetails(username);
			
		System.out.println("inside controller of mybooking"+pDetails);
		model.addAttribute("pDetails", pDetails);
			String view="MyBookings";
			return view;
		
	}
	
}
