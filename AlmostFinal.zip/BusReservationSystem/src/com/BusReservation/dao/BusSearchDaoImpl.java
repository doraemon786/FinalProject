package com.BusReservation.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.BusReservation.model.BusDetails;



@Repository
public class BusSearchDaoImpl implements IBusSearchDao {

	static Transaction tx ;
	private SessionFactory sessionFactory;
Date date1= new Date();
Date date2= new Date();
int day;
Calendar c = Calendar.getInstance();
	@Autowired // if annotated as repository then dont need to put entries in .xml
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public List<BusDetails> fetchBus(String sectorfrom, String sectorto, String journeyDate, String returnDate) {
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		
		
		
			try {
				date1=new SimpleDateFormat("MM/dd/yyyy").parse(journeyDate);
				date2=new SimpleDateFormat("MM/dd/yyyy").parse(returnDate);
				day=date1.getDay();
				
				System.out.println(sectorto);
				System.out.println(journeyDate);
				System.out.println(date1.getDay());
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		
		
			

		 
	/*SQLQuery query2 = session.createSQLQuery("select * from BusDetails  b , "
			+ "Sector s where b.sector_sectorId = s.sectorId"
			+ " and s.sectorFrom=:sectorfrom and s.sectorTo=:sectorto "
			+ "and b.day=:day");
	
	*/
			
			//SQLQuery query2 =  session.createSQLQuery("select * from BusDetails b ,sector s ");
					
Query query2=  session.createQuery("from BusDetails where sectorFrom=:sectorFrom and sectorTo=:sectorTo and day=:day ");
			query2.setString("sectorFrom",sectorfrom);
			query2.setString("sectorTo",sectorto);
			query2.setInteger("day",day);
		
		List<BusDetails> busdetails=query2.list();
	/*	for(BusDetails b:busdetails)
		{
			System.out.println(b);
		}*/
		return busdetails;
	}



}
