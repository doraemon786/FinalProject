package com.BusReservation.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.BusReservation.model.Admin;
import com.BusReservation.model.BusDetails;

@Repository
public class AdminDaoImpl implements IAdminDao {
	static Transaction tx ;
	private SessionFactory sessionFactory;
	
	@Autowired // if annotated as repository then dont need to put entries in .xml
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	@Override
	public boolean verifyAdmin(Admin a) {
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		
		String query="from Admin where username=:username and password=:password";
		
		Query q=session.createQuery(query);
		q.setString("username", a.getUsername());
		q.setString("password",a.getPassword());
		if(q.list().size()==0)
		{
			return false;
		}
		
		else
		{
			return true;
		}
		
		
	}
	@Override
	public void addBus(BusDetails busDetails) {
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		session.save(busDetails);
		tx.commit();
		session.close();
		
	}
	@Override
	public List<BusDetails> ViewAllBus() {
		Session session = this.sessionFactory.openSession();
		
		System.out.println("inside view all dao");
		String query="from BusDetails";
		Query q=session.createQuery(query);
	
		return q.list();
		
	}
	@Override
	public List<BusDetails> ViewAllUser() {
		
Session session = this.sessionFactory.openSession();
		
		System.out.println("inside view all dao");
		String query="from AuthorizedUser";
		Query q=session.createQuery(query);
	
		return q.list();
		
	}

}
