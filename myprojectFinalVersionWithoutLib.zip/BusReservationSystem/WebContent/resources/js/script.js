function updateTextArea() { 
    
  if ($("input:checked").length == ($("#numberofseats").val()))
    {
      $(".seatStructure *").prop("disabled", true);
      
      $("input:disabled").disabled=true;
     var allNumberVals = [];
     var allSeatsVals = [];
  
     //Storing in Array
    
     allNumberVals.push($("#numberofseats").val());
     $('#seatsBlock :checked').each(function() {
       allSeatsVals.push($(this).val());
     });
    
     //Displaying 
    
     $('#NumberDisplay').val(allNumberVals);
     $('#seatsDisplay').val(allSeatsVals);
    }
  else
    {
      alert("Please select " + ($("#numberofseats").val()) + " seats")
    }
  
  
  
   //$(".seatStructure *").prop("disabled", false);
  }

function myFunction() {
  alert($("input:checked").length);
}
/*
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
*/

$(":checkbox").click(function() {
  if ($("input:checked").length == ($("#numberofseats").val())) {
    $(":checkbox").prop('disabled', true);
    $(':checked').prop('disabled', false);
  }
  else
    {
      $(":checkbox").prop('disabled', false);
    }
});

function checkPasswordMatch() {
    var password = $("#password").val();
    var confirmPassword = $("#confirmPassword").val();

    if (password != confirmPassword)
        $("#divCheckPasswordMatch").html("Passwords do not match!");
    else
        $("#divCheckPasswordMatch").html("Passwords match.");
}


