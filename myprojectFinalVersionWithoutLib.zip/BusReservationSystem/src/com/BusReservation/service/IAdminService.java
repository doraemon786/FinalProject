package com.BusReservation.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.BusReservation.model.Admin;
import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;

//Interface for Admin Service
public interface IAdminService {

public	boolean verifyAdmin(Admin a);

public void addBus(BusDetails busDetails);

public List<BusDetails> ViewAllBus();

public List<AuthorizedUser> ViewAllUser();
}
