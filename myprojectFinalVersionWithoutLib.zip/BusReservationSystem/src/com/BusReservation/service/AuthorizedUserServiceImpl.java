package com.BusReservation.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BusReservation.dao.IAuthorizedUserDao;
import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.model.PassengerDetails;

//Implementation of IAuthorizedUserService by implementing IAuthorizedUserService
@Service
@Transactional
public class AuthorizedUserServiceImpl implements IAuthorizedUserService {

	@Autowired		//Dependency Injection
	IAuthorizedUserDao authorizedUserDao;
	
	//fetching password
	@Override
	public List fetchPassword(String email) {
		
		return authorizedUserDao.fetchPassword(email);
	}

	//adding user
	@Override
	public void AddUser(AuthorizedUser authuser) {
		
		authorizedUserDao.AddUser(authuser);
		
	}

	//verifying user to login
	@Override
	public boolean verifyUser(String username, String password) {
		
		return authorizedUserDao.verifyUser(username, password);
	}

	//getting user details
	@Override
	public List<AuthorizedUser> getUserDetails(String username) {
		
		return authorizedUserDao.getUserDetails(username);
	}

	//getting bus details
	@Override
	public List<BusDetails> getBusDetails(String busname) {
		
		return authorizedUserDao.getBusDetails(busname);
	}

	//registering passengers
	@Override
	public List<PassengerDetails> registerPassenger(PassengerDetails pdetail) {
		
		return authorizedUserDao.registerPassenger(pdetail);
		
	}

	//calculating seats
	@Override
	public boolean seatCalculate(String seattotal, int busId) {
		
		return authorizedUserDao.seatCalculate(seattotal, busId);
		
	}

	//getting booked seats
	@Override
	public ArrayList<String> getBookedSeats(String busname) {
		
		return authorizedUserDao.getBookedSeats(busname);
	}

	//fetching journey details
	@Override
	public List<PassengerDetails> fetchPassengerDetails(String username) {
	
		return authorizedUserDao.fetchPassengerDetails(username);
	}
}
