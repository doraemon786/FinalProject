package com.BusReservation.dao;

import java.util.List;

import com.BusReservation.model.Admin;
import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;

//Interface for Admin Operations
public interface IAdminDao {
	
	boolean verifyAdmin(Admin a);

	public void addBus(BusDetails busDetails);

	List<BusDetails> ViewAllBus();

	List<AuthorizedUser> ViewAllUser();

}
