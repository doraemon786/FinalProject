package com.BusReservation.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.BusReservation.model.BusDetails;

//Implementation of IBusSearchDao by implementing IBusSearchDao
@Repository
public class BusSearchDaoImpl implements IBusSearchDao {
	
	static Transaction tx ;
	private SessionFactory sessionFactory;
	
	//creating date objects
	Date date1= new Date();
	Date date2= new Date();
	
	int day;
	
	@Autowired // if annotated as repository then dont need to put entries in .xml
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	//method to fetch buses for displaying as a response to user search query 
	@Override
	public List<BusDetails> fetchBus(String sectorfrom, String sectorto, String journeyDate, String returnDate) {
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		
			try {
				date1=new SimpleDateFormat("MM/dd/yyyy").parse(journeyDate);
				date2=new SimpleDateFormat("MM/dd/yyyy").parse(returnDate);
			
				day=date1.getDay();		//getting day number from date
				
				//System.out.println(sectorto);															//debug code
				//System.out.println(journeyDate);							
				//System.out.println(date1.getDay());
				
			} catch (ParseException e) {
				e.printStackTrace();
			}
	
			//query to retrieve bus for user search query 
			Query query2=  session.createQuery("from BusDetails where sectorFrom=:sectorFrom and sectorTo=:sectorTo and day=:day ");
			query2.setString("sectorFrom",sectorfrom);
			query2.setString("sectorTo",sectorto);
			query2.setInteger("day",day);
		
			List<BusDetails> busdetails=query2.list();

			return busdetails;
	}
}