package com.BusReservation.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.BusReservation.model.Admin;
import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;

//Implementation of IAdminDao by implementing IAdminDao

@Repository //a marker for any class that fulfills the role of a repository.
public class AdminDaoImpl implements IAdminDao {
	
	//Declaring transaction interface reference
	static Transaction tx ;
	//Declaring sessionFactory interface reference
	private SessionFactory sessionFactory;
	
	@Autowired 
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	//Method for verifying Admin
	@Override
	public boolean verifyAdmin(Admin a) {
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		
		String query="from Admin where username=:username and password=:password";
		
		Query q=session.createQuery(query);
		q.setString("username", a.getUsername());
		q.setString("password",a.getPassword());
		
		//checking if database has any row with the given username and password
		if(q.list().size()==0)
		{
			//if username and password does not match list size will be 0 
			return false;
		}
		else
		{
			return true;
		}	
}
	
	//method for adding bus into Busdetails table
	@Override
	public void addBus(BusDetails busDetails) {
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		//inserting busDetails object into database 
		session.save(busDetails);
		tx.commit();
		session.close();
	}
	
	//method returning list of all buses
	@Override
	public List<BusDetails> ViewAllBus() {
		Session session = this.sessionFactory.openSession();
		
		//System.out.println("inside view all dao");  								//debug code
		
		String query="from BusDetails";
		Query q=session.createQuery(query);
		return q.list();
	}
	
	//method for returning list of Authorized user
	@Override
	public List<AuthorizedUser> ViewAllUser() {
		Session session = this.sessionFactory.openSession();
		
		//System.out.println("inside view all dao");							//debug code
		
		String query="from AuthorizedUser";
		Query q=session.createQuery(query);
		return q.list();
	}

}
