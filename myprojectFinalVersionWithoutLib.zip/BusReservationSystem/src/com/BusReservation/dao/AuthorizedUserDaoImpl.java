package com.BusReservation.dao;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.model.PassengerDetails;

//Implementation of IAuthorizedUserDao by implementing IAuthorizedUserDao

@Repository //a marker for any class that fulfills the role of a repository.
public class AuthorizedUserDaoImpl  implements IAuthorizedUserDao {
	//Declaring transaction interface reference
		static Transaction tx ;
		
		static Transaction tx1 ;
		//Declaring sessionFactory interface reference
		private SessionFactory sessionFactory;
	
		@Autowired 
		public void setSessionFactory(SessionFactory sf) {
			this.sessionFactory = sf;
		}
		
		//method returning password for forget password
		@Override
		public List fetchPassword(String userEmail) {
		
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			//query to retrieve user with given email
			Query query=  session.createQuery("from AuthorizedUser a where a.userEmail = :userEmail");
			query.setString("userEmail", userEmail);
			List<AuthorizedUser> list=query.list();
			//if user-email doesnt exists in database it will return null else return password
			if(list.isEmpty())
			{
				//System.out.println("null"); //debug code
				return null;
			}
			tx.commit();
			session.close();
			return list;
	}
		
		
		//adding user into database (Registeration Process)
		@Override
		public void AddUser(AuthorizedUser authuser) {
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(authuser);
			tx.commit();
			session.close();
	}

		//verifying user for login purpose
		@Override
		public boolean verifyUser(String username, String password) {
		
			Session session = this.sessionFactory.openSession();
			//query to check if user exists or not
			String query="From AuthorizedUser a where a.userEmail = :username and a.password = :password";
			Query q=session.createQuery(query);
			q.setString("username", username);
			q.setString("password", password);
			List<AuthorizedUser> list = q.list();
		  //if no user exists with given username and password then list size will be 0
			if(list.size()==0)
			{
					return false;
			}
			session.close();
			return true;
}

		//method to return userdetails to display on dashboard 
		@Override
		public List<AuthorizedUser> getUserDetails(String username) {
			Session session = this.sessionFactory.openSession();
			//query to retrieve user details with given username(email)
			String query="From AuthorizedUser a where a.userEmail = :username ";
			Query q=session.createQuery(query);
			q.setString("username", username);
			List<AuthorizedUser>	user =  q.list();
			
			//System.out.println("inside dao..........."+user);							//debug code
			
			return user;
		}

		//method to get busdetails 
		@Override
		public List<BusDetails> getBusDetails(String busname) {
			Session session = this.sessionFactory.openSession();
			//query to retrieve bus details for a given busname
			String query="From BusDetails b where b.busName = :busname ";
			Query q=session.createQuery(query);
			q.setString("busname", busname);
			List<BusDetails>	BusDetails =  q.list();
			
			//System.out.println("inside dao...."+BusDetails);					//debug code
			
			return BusDetails;
		}
		
		//method to get passenger details
		@Override
		public List<PassengerDetails> registerPassenger(PassengerDetails pdetail) {
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(pdetail);
			tx.commit();
			int pid=pdetail.getPassengerId();
			//System.out.println("pid................."+pid);									//debug code
			//query to retrieve all passenger details with the given id
			String query2="from PassengerDetails p where p.passengerId=:passengerId";
			Query q2=session.createQuery(query2);
			q2.setInteger("passengerId", pid);
			List<PassengerDetails> pdetails=q2.list();
			return pdetails;
		}

		//method for calculating available seats
		@Override
		public boolean seatCalculate(String seattotal, int busId) {
			//seattotal=number of seats selected by user
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
	
			//System.out.println("inside seatCalculate........");						//debug code
			
			//query to retrieve bus details with given bus id
			String query2="from BusDetails b where busId=:busId";
			Query q2=session.createQuery(query2);
			q2.setInteger("busId", busId);
			List<BusDetails> bDetails=q2.list();
			
			//System.out.println("inside seatCalculateDao......"+bDetails);			//debug code
			
			int seatTotal=Integer.valueOf(seattotal);			//typecast string to int
			
			//calculating current capacity
			int currentCapacity=bDetails.get(0).getSeatCapacity()-seatTotal;
			tx.commit();
			tx1 = session.beginTransaction();
			
			//System.out.println("current Capacity...."+currentCapacity);			//debug code
			
			//to check whether seats are available in the bus
			if(currentCapacity>0)
			{
			
			//query to update seat capacity in busdetails for a particular bus id
			String query1="update BusDetails b set b.seatCapacity=:capacity where b.busId=:busId";
			Query q1=session.createQuery(query1);
			q1.setInteger("capacity", currentCapacity);
			q1.setInteger("busId", busId);
			int count=	q1.executeUpdate();
		
			//query to retrieve all updated bus details with given bus id
			String query3="from BusDetails b where busId=:busId";
			Query q3=session.createQuery(query3);
			q3.setInteger("busId", busId);
		
			List<BusDetails> busUpdated=q3.list();
			
			//System.out.println(count);											//debug code
			
			tx1.commit();
			//checking whether the seat can be booked or not
			if(busUpdated.get(0).getSeatCapacity()>0)
			{
				return true;
			}
				tx1.rollback();
				tx.rollback();
				return false;
		}
			return false;	
		}

		//number of seats which are booked for the purpose of locking them for other users
		@Override
		public ArrayList<String> getBookedSeats(String busname) {
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			
			//query to retrieve all seats of particular bus for locking them
			String query="select p.seat From PassengerDetails p where p.busName=:busName ";
			
			Query q1=session.createQuery(query);
			q1.setString("busName", busname);
			ArrayList<String> seat=(ArrayList<String>) q1.list();
			
		//	System.out.println("seat of passenger..................................."+seat);			//debug code
			
			return seat;
		}

		//method to retrieve all past bookings
		@Override
		public List<PassengerDetails> fetchPassengerDetails(String username) {
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			
			//System.out.println("inside fetch passenger");									//debug code
			//System.out.println("username................"+username);						//debug code
			
			//query to retrieve all passenger details with the given username
			String query=" From PassengerDetails p where p.passengerEmail=:username ";
			Query q1=session.createQuery(query);
			q1.setString("username", username);
			List<PassengerDetails> pDetails=q1.list();
			
			//System.out.println("details of passenger..................................."+pDetails);		//debug code
			
			return pDetails;
		}
}
