package com.BusReservation.dao;

import java.util.List;

import com.BusReservation.model.BusDetails;

//Interface for BusSearch Dao
public interface IBusSearchDao {

	public List<BusDetails> fetchBus(String sectorfrom, String sectorto, String journeyDate, String returnDate);
	
}
