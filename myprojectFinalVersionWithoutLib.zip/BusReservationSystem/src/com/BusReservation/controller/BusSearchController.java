package com.BusReservation.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.BusReservation.model.BusSearchDetails;
import com.BusReservation.service.IAuthorizedUserService;
import com.BusReservation.service.IBusSearchService;

//Bus Search Controller
@Controller		//indicates that this is a controller class
public class BusSearchController {
	
	@Autowired			//Dependency Injection
	IAuthorizedUserService authorizedUserService;

	@Autowired			//Dependency Injection
	IBusSearchService bussearchservice;

	//calling service method to fetch bus
	@RequestMapping(value="/SearchBus",method=RequestMethod.POST)
	public String searchBus(Model model,HttpServletRequest req,HttpSession session)
	{
		String sectorfrom=req.getParameter("source");
		String sectorto=req.getParameter("destination");
		String journeyDate=req.getParameter("journeyDate");
		String returnDate=req.getParameter("returnDate");
		session.setAttribute("journeydate", journeyDate);
		//System.out.println("for testing......................."+journeyDate);				//debug code
	
		List busList=bussearchservice.fetchBus(sectorfrom,sectorto,journeyDate,returnDate);
		ServletContext servletContext=req.getServletContext();

		servletContext.setAttribute("BusList", busList); 	
			//System.out.println(busList);									//debug code
			String view="SearchResult";
			return view;
	}
	}

