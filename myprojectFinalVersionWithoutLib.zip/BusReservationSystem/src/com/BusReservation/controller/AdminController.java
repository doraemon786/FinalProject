package com.BusReservation.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.BusReservation.model.Admin;
import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.service.IAdminService;

//Admin Controller
@Controller		//indicates that this is a controller class
public class AdminController {

	@Autowired		//Dependency Injection
	IAdminService adminService;

	//calling Admin Login page
	@RequestMapping("/adminLogin")
	public String showLoginView(Model modal)
	{
		modal.addAttribute("admin", new Admin());
		String view="adminLogin";
		return view;
	}
	
	//verifying admin by calling service method of AdminServiceImpl
	@RequestMapping(value="/adminLoginCall",method=RequestMethod.POST)
	public String adminLoginValidation(@Valid @ModelAttribute("admin") 
	Admin admin ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		//returns true if admin found
		if(adminService.verifyAdmin(admin))
		{
			return "AdminDashBoard";
		}
		return "adminLogin";
	}

	//adding bus by calling AddBus jsp page
	@RequestMapping("/addBus")
	public String addBus(Model modal)
	{
		modal.addAttribute("busDetails", new BusDetails());
		String view="AddBus";
		return view;
	}
	
	//calling method of AdminServiceImpl
	@RequestMapping(value="/addBusProcess",method=RequestMethod.POST)
	public String addBusProcessing(@Valid @ModelAttribute("busDetails") 
	BusDetails busDetails ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		//System.out.println("inside..add bus controller");							//debug code
		adminService.addBus(busDetails);
	
		return "success";
	}
	
	//calling service method for getting all bus
	@RequestMapping("/viewBus")
	public String viewAllBus(Model model,HttpServletRequest req)
	{
		//System.out.println("inside admin view all");							//debug code
	   List<BusDetails> bDetails=adminService.ViewAllBus();
		
	   model.addAttribute("busDetails", bDetails);
		return "AllBusDetails";
	}
	
	//calling method to get all verified users
	@RequestMapping("/viewUser")
	public String viewAllUser(Model model,HttpServletRequest req)
	{
		//System.out.println("inside admin view all");								//debug code
	   List<AuthorizedUser> user=adminService.ViewAllUser();
		
	   model.addAttribute("allUser", user);
		return "AllUserDetails";
	}
	
}
