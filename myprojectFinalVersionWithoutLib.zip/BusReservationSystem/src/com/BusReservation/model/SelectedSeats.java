package com.BusReservation.model;

import java.util.Arrays;

//POJO for selected seats
public class SelectedSeats {
	private int busId;
	private int noofSeats;
	private String Seat[];
	
	//Default Constructor
	public SelectedSeats() {
		super();
	}
	
	//Parameterized Constructor
	public SelectedSeats(int busId, int noofSeats, String[] seat) {
		super();
		this.busId = busId;
		this.noofSeats = noofSeats;
		Seat = seat;
	}

	//Getters and Setters
	public int getNoofSeats() {
		return noofSeats;
	}
	public void setNoofSeats(int noofSeats) {
		this.noofSeats = noofSeats;
	}
	public String[] getSeat() {
		return Seat;
	}
	public void setSeat(String[] seat) {
		Seat = seat;
	}
	
	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	//To String of selected seats
	@Override
	public String toString() {
		return "SelectedSeats [noofSeats=" + noofSeats + ", Seat=" + Arrays.toString(Seat) + "]";
	}
	
}
