package com.BusReservation.model;

//POJO for Bus search Details
public class BusSearchDetails {

	private int busId;
	private String arrivalTime;
	private String busName;
	private String busType;
	private int day;
	private String departureTime;
	private int sector_sectorId;
	private int sectorId;
	private String sectorFrom;
	private String sectorTo;
	
	//Default Constructor
	public BusSearchDetails() {
		super();
	}
	
	//Parameterized Constructor
	public BusSearchDetails(int busId, String arrivalTime, String busName, String busType, int day,
			String departureTime, int sector_sectorId, int sectorId, String sectorFrom, String sectorTo) {
		super();
		this.busId = busId;
		this.arrivalTime = arrivalTime;
		this.busName = busName;
		this.busType = busType;
		this.day = day;
		this.departureTime = departureTime;
		this.sector_sectorId = sector_sectorId;
		this.sectorId = sectorId;
		this.sectorFrom = sectorFrom;
		this.sectorTo = sectorTo;
	}

	//Getters and Setters
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public int getSector_sectorId() {
		return sector_sectorId;
	}
	public void setSector_sectorId(int sector_sectorId) {
		this.sector_sectorId = sector_sectorId;
	}
	public int getSectorId() {
		return sectorId;
	}
	public void setSectorId(int sectorId) {
		this.sectorId = sectorId;
	}
	public String getSectorFrom() {
		return sectorFrom;
	}
	public void setSectorFrom(String sectorFrom) {
		this.sectorFrom = sectorFrom;
	}
	public String getSectorTo() {
		return sectorTo;
	}
	public void setSectorTo(String sectorTo) {
		this.sectorTo = sectorTo;
	}
	
	//To String of Bus search details
	@Override
	public String toString() {
		return "BusSearchDetails [busId=" + busId + ", arrivalTime=" + arrivalTime + ", busName=" + busName
				+ ", busType=" + busType + ", day=" + day + ", departureTime=" + departureTime + ", sector_sectorId="
				+ sector_sectorId + ", sectorId=" + sectorId + ", sectorFrom=" + sectorFrom + ", sectorTo=" + sectorTo
				+ "]";
	}
	
}
